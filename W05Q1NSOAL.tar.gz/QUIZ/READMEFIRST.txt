1. Soal akan dishare di channel #❓pop-quiz-questions 

2. Akan ada 2 file yang pengerjaannya sesuai ketentuan di file soal masing-masing

3. Jawaban dari semua soal dimasukkan ke sebuah encrypted tar bernama W05Q1N.tar.gz.asc
3.1. Tambahkan aceyoga@os.vlsm.org sebagai recipient. 
Pubkeynya sudah dikirimkan di #general.
3.2. Kegagalan mengenkripsi(tidak dapat didecrypt dst) == diskualifikasi.

4. Tar harus berisi sebuah folder bernama W05Q1N yang mengandung: 
Makefile, myaddresses.c, myaddresses_sort.<extension program>, 
dan jawaban nomor 1 dengan format: W05Q11_<akun github>_FIFO_<jawaban>
4.1. Jika perintah tar -tvf dijalankan, harusnya semua file akan 
diawali dengan W05Q1N. Contoh: W05Q1N/myaddress.c

5. Tar dikumpulkan ke channel #pop-quiz-file-answer, langsung kirim saja.